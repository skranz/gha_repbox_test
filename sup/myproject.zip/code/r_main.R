library(haven)
dat = read_dta("data/data.dta")
source("code/r_analysis.R")
source("code/r_plots.R")

cat("\nAnalysis finished!")
